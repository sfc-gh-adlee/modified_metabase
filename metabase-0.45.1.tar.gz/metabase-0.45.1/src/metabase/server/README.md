# `metabase.server.*`

Code related to the Metabase Jetty web server, excluding the REST API endpoints themselves, which live in
`metabase.api.*`.

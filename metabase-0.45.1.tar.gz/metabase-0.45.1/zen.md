# The Zen of Metabase

- Give the user value as soon as possible

- Structure things so that we can automagically infer things for the user

- Don’t ask the user for information the system should already know

- Make it easy for the user to do the right thing

- Don’t leave the user booby traps

- Go the extra mile to make the user experience pleasant 